package com.example.ques

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
